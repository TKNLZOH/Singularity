# AMRFinderPlus Singularity Pipeline

This package allows you to run AMRFinderPlus on a folder of FASTA files using Singularity.

## Features

- Species selection from predefined NCBI list.
- Automatically installs and runs AMRFinderPlus.
- Outputs a single Excel file summarizing gene hits per sample.

## Usage

```bash
singularity build amrfinder.sif Singularity
./amrfinder.sif /path/to/fasta_folder
```

## Requirements

- Singularity installed
- Input directory with `.fasta` files

