#!/bin/bash
set -e

# === Check AMRFinder ===
if ! command -v amrfinder &> /dev/null; then
    echo "AMRFinder not found. Installing with Conda..."

    if ! command -v conda &> /dev/null; then
        echo "Conda is required but not found. Please install Miniconda or Anaconda first."
        exit 1
    fi

    conda create -y -n amrfinder_env -c bioconda ncbi-amrfinderplus
    source "$(conda info --base)/etc/profile.d/conda.sh"
    conda activate amrfinder_env

    echo "Downloading AMRFinderPlus database..."
    amrfinder -u
else
    echo "AMRFinder is already installed."
fi

# === Species options ===
declare -A SPECIES_MAP=(
  [1]="Acinetobacter_baumannii"
  [2]="Burkholderia_cepacia"
  [3]="Burkholderia_mallei"
  [4]="Burkholderia_pseudomallei"
  [5]="Campylobacter"
  [6]="Citrobacter_freundii"
  [7]="Clostridioides_difficile"
  [8]="Corynebacterium_diphtheriae"
  [9]="Enterobacter_asburiae"
  [10]="Enterobacter_cloacae"
  [11]="Enterococcus_faecalis"
  [12]="Enterococcus_faecium"
  [13]="Escherichia"
  [14]="Haemophilus_influenzae"
  [15]="Klebsiella_oxytoca"
  [16]="Klebsiella_pneumoniae"
  [17]="Neisseria_gonorrhoeae"
  [18]="Neisseria_meningitidis"
  [19]="Pseudomonas_aeruginosa"
  [20]="Salmonella"
  [21]="Serratia_marcescens"
  [22]="Staphylococcus_aureus"
  [23]="Staphylococcus_pseudintermedius"
  [24]="Streptococcus_agalactiae"
  [25]="Streptococcus_pneumoniae"
  [26]="Streptococcus_pyogenes"
  [27]="Vibrio_cholerae"
  [28]="Vibrio_parahaemolyticus"
  [29]="Vibrio_vulnificus"
)

echo "Select the organism for AMRFinder:"
echo "  0) None / Not listed"
for i in "${!SPECIES_MAP[@]}"; do
  echo "  $i) ${SPECIES_MAP[$i]}"
done

read -rp "Enter the number corresponding to your organism: " SPECIES_NUM

ORGANISM="${SPECIES_MAP[$SPECIES_NUM]}"

if [[ "$SPECIES_NUM" != "0" && -z "$ORGANISM" ]]; then
  echo "Invalid selection. Exiting."
  exit 1
fi

# === Input folder check ===
INPUT_DIR="$1"
if [[ -z "$INPUT_DIR" || ! -d "$INPUT_DIR" ]]; then
  echo "Usage: $0 <path_to_fasta_folder>"
  exit 1
fi

# === Prepare output ===
OUTPUT_DIR="amrfinder_results"
mkdir -p "$OUTPUT_DIR"

echo "Running AMRFinderPlus..."
for fasta in "$INPUT_DIR"/*.fasta; do
  sample=$(basename "$fasta" .fasta)
  if [[ "$SPECIES_NUM" == "0" ]]; then
    amrfinder -n "$fasta" -o "$OUTPUT_DIR/${sample}.tsv"
  else
    amrfinder -n "$fasta" --organism "${ORGANISM//_/ }" -o "$OUTPUT_DIR/${sample}.tsv"
  fi
done

# === Generate Full Excel Summary ===
echo "Creating Excel summary..."
python3 <<EOF
import os
import pandas as pd
from xlsxwriter import Workbook

input_dir = "$OUTPUT_DIR"
output_excel = "amrfinder_summary.xlsx"

# Collect all TSV data
dfs = []
for file in sorted(os.listdir(input_dir)):
    if file.endswith(".tsv"):
        sample = file.replace(".tsv", "")
        df = pd.read_csv(os.path.join(input_dir, file), sep='\t')
        df.insert(0, "Sample", sample)
        dfs.append(df)

# Concatenate all into one DataFrame
if dfs:
    combined = pd.concat(dfs, ignore_index=True)
    combined.to_excel(output_excel, index=False)
else:
    print("No TSV files found to summarize.")
EOF

echo "Done. Summary saved as amrfinder_summary.xlsx"
